############### Author information And Copyringht ########################
#@Author Gao Hua,Yang Guowen,Tong Chunfa
#@Date 03/11/2019
#@define leaf processing 
#@Version 1.1
#@Email spu112005@live.com
#Description 

############## check depend librarys #####################################
checkpacks <- function(packages = c()){
  # check packages
  # Usage
  # checkpacks("bmp")
  packs <- rownames(installed.packages()) #list all packages
  #compare and install 
  readypack <-(.packages())
  for(p in packages){
    if(p %in% readypack) next()
    if(is.na(match(p,packs))){
      if(p == "EBImage"){
        if (!requireNamespace("BiocManager", quietly = TRUE))
          install.packages("BiocManager")
			BiocManager::install("EBImage")
      }else{
        print(paste("install depended packages:",p))
        install.packages(p)
      }
    }
  }
}

#===========read leaf pics===============================================
############## pic informations ##########################################
cprocess <- function(path = "",filename,threshold = 0.75){
 	checkpacks(c("bmp","pixmap"))
   	library(bmp)
   	library(pixmap)
   	library(jpeg)
  	checkpacks("EBImage")
  	library("EBImage")
  	filenames <- paste(path,filename,".bmp",sep = "")
  	r <- read.bmp(filenames) #read files
	hres <- attr(r,"header")$hres
	vres <- attr(r,"header")$vres
	if(hres < 50 || vres < 50){
		stop("The picture has no resolution information!\n")
	}
	width <- attr(r,"header")$width
	height <- attr(r,"header")$height
	w20 <- as.integer(width/20)
	h20 <- as.integer(height/20)
    pg <- pixmapGrey(r,cellres=c(hres,vres))
	img0 <- t(pg@grey)
	
  	picsize <-c(width/hres,height/vres)*1000   #mm          		## modified 22/06/2019
  	pixArea <-prod(picsize/dim(img0))			## modified 22/06/2019
  	img <- img0[w20:(width-w20),h20:(height-h20)]
 
  	w = makeBrush(size = 5, shape = 'gaussian', sigma = 0.5)
  	imgcut = filter2(img, w)
  	imgcuts <- imgcut < threshold
  	imgcuts <- medianFilter(imgcuts,5,512)
  	imgcuts <- fillHull(imgcuts)
  	imgcuts <- imgcuts > threshold
  	imgcuts <- flip(imgcuts)
  	contour = ocontour(imgcuts)[[1]]

	cimgcuts<- imgcuts > 0
  
  	Area <- sum(cimgcuts)
  	xsum <- apply(cimgcuts,2,sum)
  	ysum <- apply(cimgcuts,1,sum)
  
  	xmin <- min(contour[,1])
  	xmax <- max(contour[,1])
  	ymin <- min(contour[,2])
  	ymax <- max(contour[,2])
  
  	xsum <- xsum[(ymin+1):(ymax+1)]
  	ysum <- ysum[(xmin+1):(xmax+1)]
  
  	xsum <- xsum%*%c(ymin:ymax)
  	ysum <- ysum%*%c(xmin:xmax)
  	y <- xsum/Area
  	x <- ysum/Area

  	realArea <- pixArea*Area

	dmg0 <- dim(img0)									## modified 22/06/2019
	contour[,1] <- contour[,1]*picsize[1]/dmg0[1]		## modified 22/06/2019
	contour[,2] <- contour[,2]*picsize[2]/dmg0[2]		## modified 22/06/2019

	x <- x*picsize[1]/dmg0[1]							## modified 22/06/2019
	y <- y*picsize[2]/dmg0[2]							## modified 22/06/2019
	
  	return(list(imgpath = filenames,contour = contour,area = realArea,wxy=c(x,y)))  ## modified 22/06/2019
}

############## rectA 2 polar function ##############################################
rect2polar<-function(rectcoor = NA,weightP = c(0,0)){
  #covert rectangle coordinaes to polar coordinates
  #must be center to the zero point
  #USage PolarCoordinate <- rect2polar(rectACoor,weightPoints)
  rectcoor[,1] <- rectcoor[,1] - weightP[1] #center to zero Points #x
  rectcoor[,2] <- rectcoor[,2] - weightP[2] #y
  len <- nrow(rectcoor) #Count of Points

  for(i in 1:len){
    x <- rectcoor[i,1]
    y <- rectcoor[i,2]
    if(x >= 0){
      angle <- atan(y/x)
    }else{
      if(y > 0){
        angle <- atan(y/x) + pi
      }else{
        angle <- atan(y/x) - pi
      }
    }
    rectcoor[i,1] <- angle
    rectcoor[i,2] <- sqrt(x^2+y^2)
  }
  return(rectcoor)
}

correctPolarShape <- function(polardata){
	pd <- polardata
	yr <- pd[,2]*sin(pd[,1])
	pdy <- cbind(pd,yr)
	pdy1 <- pdy[order(pdy[,3]),]
	n <- dim(pdy1)[1]
	ch <- mean(pdy1[(n-9):n,1]) - pi/2
	rh <- mean(pdy1[(n-9):n,2])

	if(ch>0){
		pd2 <- pd
		pd2[,1] <- pd2[,1] - ch
		for(i in 1:n){
			if(pd2[i,1] < -pi){ pd2[i,1] <- 2*pi + pd2[i,1] }
		}
	}
	if(ch<0){
		pd2 <- pd
		pd2[,1] <- pd2[,1] - ch
		for(i in 1:n){
			if(pd2[i,1] > pi){ pd2[i,1] <- pd2[i,1] - 2*pi}
		}
	}

	return(list(pd2 = pd2,highrho = rh))
}

take360pd <- function(fullpd){
	pd360 <- matrix(0,360,2)
	ls <- seq(-pi,pi,2*pi/360)
	for(i in 1:360){
		tmp <- fullpd[(fullpd[,1]>=ls[i]) & (fullpd[,1]<ls[i+1]),2]
		pd360[i,1] <- (ls[i] + ls[i+1])/2
		if(length(tmp)>0){
			pd360[i,2] <- mean(tmp)
		}
	}
	
	for(i in 2:359){
		if(pd360[i,2] == 0){
			pd360[i,2] <- (pd360[i-1,2] + pd360[i+1,2])/2
		}
	}
	
	if(pd360[1,2] == 0){
		pd360[1,2] <- (pd360[360,2] + pd360[2,2])/2
	}
	if(pd360[360,2] == 0){
		pd360[360,2] <- (pd360[1,2] + pd360[359,2])/2
	}

	return(pd360)
}

plottoPDF <- function(pd0 = pd0data,pd360 = pd360data,trtdt = traitdata,
			outpath = "",filename = "",cexs = 0.6,pchs = 20){
  # USAGE 
  #for sigle divided should include
  #for sigle family default rectA should include
  #for all Polar rectA should be FALSE

	parm = c(paste(filename,": A"),paste(filename,": B"),
			  paste(filename,": C"),paste(filename,": D"))

	data1 <- pd0
	data2 <- pd360
	data1[,1] <- cos(pd0[,1])*pd0[,2]
	data1[,2] <- sin(pd0[,1])*pd0[,2]
	data2[,1] <- cos(pd360[,1])*pd360[,2]
	data2[,2] <- sin(pd360[,1])*pd360[,2]

  	pdffile <- paste(outpath,filename,".pdf",sep = "")
  
  	opar <- par(no.readonly = TRUE) #save default
  	par(omi = c(0.12,0.12,0.12,0.12)) #out margin 
  	par(mai = c(0.39,0.39,0.2,0.2)) #margin include axia 1.5cm 1.5cm 0.5cm 0.5cm
  
    pdf(pdffile,pointsize = 4,width = 8,height = 8)
    nf <-layout(rbind(c(1,2),
						c(0,0),
                      c(3,4)),
                heights=c(3, lcm(0.3), 3)
    )
	par(cex.main=2.5,cex.axis=2.0)
    plot(data1,col = "blue",cex = cexs,pch = pchs,main = parm[1],asp = 1,xlab = "X",ylab = "Y")
    plot(data2,col = "red",cex = cexs,pch = pchs,main = parm[2],asp = 1,xlab = "X",ylab = "Y")
    plot(data1,col = "blue",cex = cexs,pch = pchs,main = parm[3],asp = 1,xlab = "X",ylab = "Y")
    points(data2,col = "red",cex = cexs,pch = pchs)
  	plot(data2,col="red",cex=cexs,pch=pchs,main=parm[4],asp=1,xlab="X",ylab="Y")
	for(i in 1:2){
		segments(trtdt[i,1],trtdt[i,2],trtdt[i,3],trtdt[i,4],col="red")
	}
	for(i in 3:5){
		segments(trtdt[i,1],trtdt[i,2],trtdt[i,3],trtdt[i,4],col="blue")
	}
  	par(opar)
  	dev.off()
}

distance <- function(xy1,xy2){
	ds <- (xy1[1]-xy2[1])^2 + (xy1[2]-xy2[2])^2
	ds <- ds^0.5
	return(ds)
}

leaftraits <- function(pd360 = pd360,origpd = crtpd){
	rh <- origpd$highrho
	rl <- mean(pd360[(pd360[,1]>(-pi/2-0.02))&(pd360[,1]<(-pi/2+0.02)),2])
	leaflength <- rh + rl

	data <- pd360
	data[,1] <- cos(pd360[,1])*pd360[,2]
	data[,2] <- sin(pd360[,1])*pd360[,2]

	y <- c(-rl)
	d <- leaflength/60
	for(i in 1:59){
		di <- i*d
		if(di < rl){
			y <- c(y,-rl + di)
		}else{
			di <- di - rl
			y <- c(y,di)
		}
	}
	y <- c(y,rh)

	pt61L <- matrix(0,61,2)
	pt61R <- matrix(0,61,2)
	pt61L[1,] <- c(0,-rl)
	pt61L[61,] <- c(0,rh)
	pt61R[1,] <- c(0,-rl)
	pt61R[61,] <- c(0,rh)

	for(i in 2:59){
		tmp1 <- data[abs(data[,2]-y[i])<d/2 & data[,1]<= 0,]
		tmp2 <- data[abs(data[,2]-y[i])<d/2 & data[,1]>= 0,]
		if(length(tmp1)>2){
			tmp3 <- tmp1[order(abs(tmp1[,2]-y[i])),]
			pt61L[i,] <- tmp3[1,]
		}else if(length(tmp1)==0){
			pt61L[i,] <- c(0,y[i])
		}else{
			pt61L[i,] <- tmp1
		}
		if(length(tmp2)>2){
			tmp4 <- tmp2[order(abs(tmp2[,2]-y[i])),]
			pt61R[i,] <- tmp4[1,]
		}else if(length(tmp2)==0){
			pt61R[i,] <- c(0,y[i])
		}else{
			pt61R[i,] <- tmp2
		}
	}
	
	dst <- rep(0,59)
	for(i in 2:60){
		dst[i-1] <- distance(pt61L[i,],pt61R[i,])
	}

	width31 <- dst[20]
	width21 <- dst[30]
	width32 <- dst[40]
	width <- max(dst)
	maxdsti <- which(dst==width)[1]

	area = sum(pd360[,2]^2)*pi/360

	lengthwidth <- matrix(0,6,5,dimnames=list(c("Length","Width","Width31","Width21",
		"Width32","Area"),c("Point1X","Point1Y","Point2X","Point2Y","Distance/Area")))
	lengthwidth[1,] <- c(0,-rl,0,rh,leaflength)
	lengthwidth[2,] <- c(pt61L[maxdsti+1,],pt61R[maxdsti+1,],width)
	lengthwidth[3,] <- c(pt61L[21,],pt61R[21,],width31)
	lengthwidth[4,] <- c(pt61L[31,],pt61R[31,],width21)
	lengthwidth[5,] <- c(pt61L[41,],pt61R[41,],width32)
	lengthwidth[6,] <- c(0,0,0,0,area)

	return(lengthwidth)
}

############## sigle leaf main function #############################################

#  main test
leafshapemain <- function(picpath = "",outpath = "",filename = ""){ 
	if(!dir.exists(picpath)){
		stop(paste("Error: the path",picpath,"does not exist!\n"))
	}
	if(!dir.exists(outpath)){
		dir.create(	outpath)	
	}

	rst <- cprocess(picpath,filename)
	pd0 <- rect2polar(rst$contour,rst$wxy)

	crtpd <- correctPolarShape(pd0)

	pd360 <- take360pd(crtpd$pd2)

	trtdata <- leaftraits(pd360,crtpd)

    #save xy data
	outcsvpath <- paste(outpath,"csv/",sep="")
	if(!dir.exists(outcsvpath)){
		dir.create(outcsvpath)
	}
   	xydatafile <- paste(outcsvpath,filename,"_xy.csv",sep="")
	xydata <- rst$contour
	colnames(xydata) <- c("x(mm)","y(mm)")
	write.csv(xydata,xydatafile,row.names = FALSE)

	# save polar data
   	pd0datafile <- paste(outcsvpath,filename,"_pd.csv",sep="")	
   	pddatafile <- paste(outcsvpath,filename,"_pd360.csv",sep="")
	colnames(pd0) <- c("theta","r(mm)")
	colnames(pd360) <- c("theta","r(mm)")
	write.csv(pd0,pd0datafile,row.names = FALSE)
	write.csv(pd360,pddatafile,row.names = FALSE)

	# save trait data
	traitfile <- paste(outcsvpath,filename,"_traits.csv",sep="")	
	write.csv(trtdata,traitfile)

	# plotting
	outpdfpath <- paste(outpath,"pdf/",sep="")
	if(!dir.exists(outpdfpath)){
		dir.create(outpdfpath)
	}
	plottoPDF(pd0,pd360,trtdata,outpdfpath,filename)

 }

#picpath <- "C:/Manuscripts/YangWG/leaf0412/"
#outpath <- "C:/Manuscripts/YangWG/leaf0412/out/"
#filename <- "A3-0-1"
#filename <- "A301test"
#leafshapmain(picpath,outpath,filename)
