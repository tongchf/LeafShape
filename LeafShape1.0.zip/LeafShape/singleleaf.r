Args <- commandArgs()
arglth <- length(Args)
if(arglth != 11)
{
cat("\nProgram: singleleaf.r (Extracting the shape data from a single tree leaf with a bmp file)\n")
cat("Version: 1.0\n")
cat("Contact: Chunfa Tong <tongchf@njfu.edu.cn>\n\n")
cat("Usage: Rscript singleleaf.r -b bmpdir -i bmpfile -d outpath\n\n")
stop("Note: Parameter error!")
}

bmpdir = NULL
outpath = NULL
bmpfile = NULL

for(i in seq(6,arglth,2)){
	if(Args[i]=="-i"){
		bmpfile=Args[i+1]
	}else if(Args[i]=="-d"){
		outpath=Args[i+1]
	}else if(Args[i]=="-b"){
		bmpdir=Args[i+1]
	}
}

bmpdir <- chartr("\\","//",bmpdir)
outpath  <- chartr("\\","//",outpath)
if(!dir.exists(bmpdir)){
	stop(paste("\nError: the path ",bmpdir," does not exist!\n",sep=""))
}
if(!dir.exists(outpath)){
	stop(paste("\nError: the path \"",outpath,"\" does not exist!\n",sep=""))
}
fullfilename = paste(bmpdir,"/",bmpfile,".bmp",sep="")
if(!file.exists(fullfilename)){
	stop(paste("\nError: the bmp file \"",fullfilename,"\" does not exist!\n",sep=""))
}

leafsdpath <- gsub("--file=","",Args[4])
leafsdpath <- gsub("singleleaf\\.r","",leafsdpath)

source(paste(leafsdpath,"leafFunctions.r",sep=""))
leafshapemain(bmpdir,outpath,bmpfile)

