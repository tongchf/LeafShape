usage <- function(){
	cat("\nProgram: stovl.r (Extracting the shape data from multiple tree leavies with bmp files)\n")
	cat("Version: 1.0\n")
	cat("Contact: Chunfa Tong <tongchf@njfu.edu.cn>\n\n")
	cat("Usage:  Rscript stovl.r -p 0 -b bmpdir -d outpath\n\n")
	cat("                   or\n\n")
	cat("        Rscript stovl.r -p 1 -d outpath\n\n")
	cat("where p = 0 for extracting leaf data and p = 1 for merging individual data into two final csv files\n")
	stop("Note: Parameter error!")
}

Args <- commandArgs()
arglth <- length(Args)
if(arglth != 9 & arglth != 11){
	usage()
}

bmpdir = NULL
outpath = NULL
flag = -1
for(i in seq(6,arglth,2)){
	if(Args[i]=="-b"){
		bmpdir=Args[i+1]
	}else if(Args[i]=="-d"){
		outpath=Args[i+1]
	}else if(Args[i]=="-p"){
		flag = Args[i+1]
	}
}

outpath  <- chartr("\\","//",outpath)
if(!grepl("/$",outpath)){
	outpath <- paste(outpath,"/",sep="")
}
if(!dir.exists(outpath)){
	stop(paste("\nError: the path \"",outpath,"\" does not exist!\n",sep=""))
}

if(flag == 0){
	bmpdir <- chartr("\\","//",bmpdir)
	if(!grepl("/$",bmpdir)){
		bmpdir <- paste(bmpdir,"/",sep="")
	}
	if(!dir.exists(bmpdir)){
		stop(paste("\nError: the path ",bmpdir," does not exist!\n",sep=""))
	}

	csvdir <- paste(outpath,"csv",sep="")
	pdfdir <- paste(outpath,"pdf",sep="")
	if(!dir.exists(csvdir)){
		dir.create(csvdir)
	}
	if(!dir.exists(pdfdir)){
		dir.create(pdfdir)
	}
	
	files0 <- dir(bmpdir,".bmp")
	files <- gsub("\\.bmp","",files0)
	nf <- length(files)

	lfsdpath <- gsub("--file=","",Args[4])
	lfsdpath <- gsub("stovl\\.r","",lfsdpath)

	for(i in 1:nf){
		cmd <- paste("Rscript ",lfsdpath,"leafsd.r -b",sep="")
		cmd <- paste(cmd,bmpdir,"-i",files[i],"-d",outpath)
		system(cmd)
		cat(paste("File",i,":",files0[i],"finished!\n"))
	}
}else if(flag == 1){
	csvpath <- paste(outpath,"csv/",sep="")
	if(!dir.exists(csvpath)){
		stop(paste("\nError: the path ",csvpath," does not exist!\n",sep=""))
	}
	files <- dir(csvpath,"pd360.csv")
	filenames <- gsub("_pd360.csv","",files)
	n <- length(files)
	allpd360 <- matrix(0,n,360,dimnames=list(filenames,seq(1:360)))
	for(i in 1:n){
		pdifile <- paste(csvpath,files[i],sep="")
		pdi <- read.csv(pdifile)
		allpd360[i,] <- pdi[,2]
	}
	allpd360outfile <- paste(outpath,"AllSamplesPD360.csv",sep="")
	write.csv(allpd360,allpd360outfile)
	
	files <- dir(csvpath,"traits.csv")
	filenames <- gsub("_traits.csv","",files)
	n <- length(files)
	allLWA <- matrix(0,n,6,dimnames=list(filenames,c("Length","Width","1/3Width",
 						"1/2Width","2/3Width","Area")))
	for(i in 1:n){
		traitifile <- paste(csvpath,files[i],sep="")
		traiti <- read.csv(traitifile)
		allLWA[i,] <- traiti[,6]
	}
	allLWAoutfile <- paste(outpath,"AllSamplesLWA.csv",sep="")
	write.csv(allLWA,allLWAoutfile)

	
}else{
	usage()
}






